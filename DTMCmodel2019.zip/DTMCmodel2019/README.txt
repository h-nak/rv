	Constructed DTMC models for experiments

					March. 2nd. 2019
					Hiroyuki Nakagawa

This data is used for the experiments on the paper entitled
"Expression Caching for Runtime Verification Based on 
Parameterized Probabilistic Models."

In this experiments, we consider the following three cases: 
- Exp. 1: One state addition into a group
- Exp. 2: Two states addition into a group
- Exp. 3: Addition of one state with two transitions to or 
          from two different groups

Constructed models for these three cases are stored in individual
directories named "Exp1", "Exp2", and "Exp3".

In these directories, numbered sub-directories are located. These
number, such as "11" and "14", represents the state size. 

These numbered directories contain two files: "Model.txt" and 
"AfterAdaptationModel.txt". The former represents the DTMC model 
before adaptation; the latter represents the one after adaptation.

A DTMC model is defined as a matrix format. Elements in the matrix 
represent transition probabilities and are separated by tab. 
Each element forms the following two symbols:
- A numerical number represents a 10,000-fold probability.
- A form such as "x[1]" and "x[2]" represents a variable (x1 and x2).


